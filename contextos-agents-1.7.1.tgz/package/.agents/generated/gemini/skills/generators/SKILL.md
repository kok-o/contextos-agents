---
name: generators
description: >
  Generates complete project documentation (PRD, Architecture, Database, API, UI, Roadmap, Tasks) from ideas and templates with incremental update support.
---
# document-generator

## Overview

Automated technical documentation generator. Transforms initial project ideas and specs into comprehensive PRDs, architecture schemas, API contracts, database ERDs, and roadmap task breakdowns.

## When to Use

Activate during project kickoff (ctx init), new service scaffolding, or when generating baseline technical specs from high-level user requirements.

## Rules & Patterns

You generate project documentation from a user's idea. Use the templates in `templates/` as the structure for each document.

## Commands

### `ctx init`

Full project initialization. From one user prompt, generate ALL documents:

1. Ask clarifying questions (see Context OS SKILL.md)
2. Select profile and skill pack
3. Generate documents in this order:
   - `docs/PRD.md` — Product Requirements (from template)
   - `docs/ARCHITECTURE.md` — System Architecture
   - `docs/DATABASE.md` — Database Schema
   - `docs/API.md` — API Specification
   - `docs/UI.md` — UI/UX Specification
   - `docs/ROADMAP.md` — Development Roadmap
   - `docs/TASKS.md` — Task Breakdown
   - `docs/PROJECT_GRAPH.md` — Project Graph
4. Create `docs/decisions/` directory for future ADRs
5. Generate agent config via Adapters skill

### `ctx update`

Incremental update. When requirements change:

1. Identify which documents are affected
2. Update only affected documents
3. Show diff of changes
4. Ask user to confirm
5. Update Project Graph if structure changed

### `ctx plan`

Generate development plan from existing PRD:

1. Read `docs/PRD.md`
2. Break into modules (Project Graph)
3. Break modules into features
4. Break features into tasks
5. Estimate complexity (S/M/L/XL)
6. Output to `docs/TASKS.md`

## Template Usage

Each template contains:

- **Section headers** — required sections for the document
- **Placeholder prompts** — `{{description}}` markers that guide content generation
- **Examples** — sample content to illustrate the expected format
- **Validation rules** — what must be present for the document to be valid

When generating a document:

1. Read the template
2. Fill in each section based on the user's idea and clarifying answers
3. Replace all `{{placeholders}}` with real content
4. Remove the template comments (lines starting with `<!-- -->`)
5. Validate: ensure all required sections are present

## Document Dependencies

```
PRD.md
  ├── ARCHITECTURE.md
  │     ├── DATABASE.md
  │     ├── API.md
  │     └── DEPLOYMENT.md
  ├── UI.md
  ├── ROADMAP.md
  │     └── TASKS.md
  └── PROJECT_GRAPH.md
```

When updating a parent document, check if child documents need updates too.


## Code Examples

See `EXAMPLES.md` for detailed code examples.

## Validation Checklist

What to verify during the review phase before completing the task.

## Common Mistakes

Anti-patterns and things to explicitly avoid. See `TROUBLESHOOTING.md`.

## Integration Notes

How this skill interacts with other skills.


<!-- Source: EXAMPLES.md -->

# generators Examples — Anti-patterns vs ContextOS Standard

## Example 1: Technical Documentation Generation

### Anti-pattern: Scaffolding from Scratch Without Templates

```text
Agent drafts a 2-paragraph "architecture overview" missing databases, security, and hosting models.
```

### Best practice: ContextOS Standard (ctx init Template Generation)

```text
Generates complete engineering suite:
- PRD.md (User personas, in-scope, out-of-scope, acceptance criteria)
- ARCHITECTURE.md (C4 model, data flow, scaling boundaries)
- DATABASE.md (ERD, indexing strategy, migration plans)
- API.md (OpenAPI 3.1 endpoints, error codes, authentication)
```

<!-- Source: TROUBLESHOOTING.md -->

# generators Troubleshooting & Common Mistakes

## 1. Generic Boilerplate Generation

- **Symptom**: Generated documentation contains placeholders like [Insert DB Name here].
- **Root Cause**: Generating docs before clarifying core project constraints.
- **Fix**: Run the interview-me protocol before generating technical documentation.
